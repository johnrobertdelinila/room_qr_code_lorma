package com.example.johnrobertdelinila.roomqrcode.utils;

public class Transaction {
    private String vendorId, ticketerId, type, date;
    private int amount;

    public Transaction() {}

    public Transaction(String vendorId, String ticketerId, String type, String date, int amount) {
        this.vendorId = vendorId;
        this.ticketerId = ticketerId;
        this.type = type;
        this.date = date;
        this.amount = amount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getVendorId() {
        return vendorId;
    }

    public void setVendorId(String vendorId) {
        this.vendorId = vendorId;
    }

    public String getTicketerId() {
        return ticketerId;
    }

    public void setTicketerId(String ticketerId) {
        this.ticketerId = ticketerId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
