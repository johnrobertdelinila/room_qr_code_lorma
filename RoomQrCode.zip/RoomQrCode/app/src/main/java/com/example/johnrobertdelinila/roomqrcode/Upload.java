package com.example.johnrobertdelinila.roomqrcode;

import com.google.firebase.firestore.ServerTimestamp;

import java.util.Date;

public class Upload {
    String code, imei, key;
    Boolean isTimeIn;
    private @ServerTimestamp Date timestamp;

    public Upload() {}

    public Upload(String rawValue, String imei, Date timestamp, Boolean isTimeIn) {
        this.code = rawValue;
        this.imei = imei;
        this.timestamp = timestamp;
        this.isTimeIn = isTimeIn;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String rawValue) {
        this.code = rawValue;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Object getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public Boolean getTimeIn() {
        return isTimeIn;
    }

    public void setTimeIn(Boolean timeIn) {
        isTimeIn = timeIn;
    }

    public void removeKey() {
        if (key != null) {
            key = null;
        }
    }

}
