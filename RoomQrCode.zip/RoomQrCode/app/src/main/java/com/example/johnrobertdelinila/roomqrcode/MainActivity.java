package com.example.johnrobertdelinila.roomqrcode;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.bottomappbar.BottomAppBar;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ServerValue;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QuerySnapshot;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.tapadoo.alerter.Alerter;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements NavigationHost {

    public static String rawValue;
    public static boolean isPerfomedQrScan = false;
    public static final int READ_PHONE_PERMISSION = 2000;

    /*private BottomAppBar bottomAppBar;
    private BottomNavigationView bottomNavigationView;*/

    private KProgressHUD hud;
    private TextView textNoData;
    private Switch aSwitch;
    // Realtime database
    private static FirebaseDatabase mDatabase = FirebaseDatabase.getInstance();
    public static DatabaseReference rootRef = mDatabase.getReference();
    public static DatabaseReference imeiRef = rootRef.child("attendance");
    private Query notificationRef = null;
    private ChildEventListener notificationListener = new ChildEventListener() {
        @Override
        public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
            // TODO: Show the notification
            String message = dataSnapshot.child("message").getValue(String.class);
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            Map<String, Object> updateSeen = new HashMap<>();
            updateSeen.put("seen", true);
            dataSnapshot.getRef().updateChildren(updateSeen);
        }

        @Override
        public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

        }

        @Override
        public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

        }

        @Override
        public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    };
    // Firestore
    private FirebaseFirestore mFirestore = FirebaseFirestore.getInstance();
    private CollectionReference attendance = mFirestore.collection("attendance");
    private CollectionReference notifications = mFirestore.collection("notifications");
    private com.google.firebase.firestore.Query notificationQuery = null;
    private ListenerRegistration notificationReg = null;

    private DatabaseHelper mDatabaseHelper;

    private ArrayList<Upload> uploads = new ArrayList<>();
    private MyAdapter myAdapter;
    private String IMEI = null;
    private boolean isTimeIn = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        hud = KProgressHUD.create(this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel(getString(R.string.text_please_wait))
                .setCancellable(true)
                .setAnimationSpeed(2)
                .setDimAmount(0.5f);

        mDatabaseHelper = new DatabaseHelper(getApplicationContext());
        textNoData = findViewById(R.id.text_no_data);
        myAdapter = new MyAdapter(uploads, this, mDatabaseHelper, textNoData);
        aSwitch = findViewById(R.id.switch_time);

        aSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> isTimeIn = !isChecked);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new DividerItemDecoration(recyclerView.getContext(), DividerItemDecoration.VERTICAL));

        populateRecyclerView(recyclerView);

       /* bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomAppBar = findViewById(R.id.bar);
        setSupportActionBar(bottomAppBar);

        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.container, new MyScansFragment())
                    .commit();
        }

        findViewById(R.id.fab).setOnClickListener(v -> {
            BarcodeGraphic.numOfSuccessRead = 0;
            startActivity(new Intent(MainActivity.this, CameraActivity.class));
        });

        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.my_scans:
                    navigateTo(new MyScansFragment(), false);
                    return true;
                case R.id.profile:
                    navigateTo(new ProfileFragment(), false);
                    return true;
                default:
                    return true;
            }
        });*/

        fetchImei();

        findViewById(R.id.fab).setOnClickListener(v -> {
            BarcodeGraphic.numOfSuccessRead = 0;
            startActivity(new Intent(MainActivity.this, CameraActivity.class));
        });
    }

    private void populateRecyclerView(RecyclerView recyclerView) {
        Cursor data = mDatabaseHelper.getData();
        while(data.moveToNext()) {
            String rawValue = data.getString(3);
            String imei = data.getString(1);
            String key = String.valueOf(data.getInt(0));
            String timestamp = data.getString(2);
            Date offlineDate = new Date(Long.parseLong(timestamp));
            Upload upload = new Upload(rawValue, imei, offlineDate, isTimeIn);
            upload.setKey(key);

            uploads.add(upload);
        }
        myAdapter = new MyAdapter(uploads, this, mDatabaseHelper, textNoData);
        recyclerView.setAdapter(myAdapter);
        showTextNoData();
    }

    @Override
    public void navigateTo(Fragment fragment, boolean addToBackstack) {
        FragmentTransaction transaction = getSupportFragmentManager()
                .beginTransaction();

        if (addToBackstack) {
            transaction.addToBackStack(null);
        }
        transaction.replace(R.id.container, fragment);
        transaction.commit();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (isPerfomedQrScan) {
            showConfirmationUpload();
            isPerfomedQrScan = false;
            BarcodeGraphic.numOfSuccessRead = 0;
        }
        listenForNotification();
    }

    private void showConfirmationUpload() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Attendance");
        Long timestamp = new Timestamp(System.currentTimeMillis()).getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String timeIn = sdf.format(new Date(timestamp));
        dialog.setMessage("Time: " + timeIn + "\n Are you sure to "+(isTimeIn ? "Time In" : "Time Out")+"?");
        dialog.setNegativeButton("CANCEL", (dialog1, which) -> dialog1.dismiss());
        dialog.setPositiveButton("CONFIRM", (dialog1, which) -> {
            if (IMEI != null) {
                uploadToDatabase();
            }else {
                Toast.makeText(this, "Can't get your phone's IMEI.", Toast.LENGTH_SHORT).show();
            }
        });
        dialog.show();
    }

    @SuppressLint("HardwareIds")
    private void fetchImei() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {
                    Manifest.permission.READ_PHONE_STATE
            }, MainActivity.READ_PHONE_PERMISSION);
        }else {
            TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Please turn on the permission request for IMEI in the settings.", Toast.LENGTH_SHORT).show();
                return;
            }
            IMEI = telephonyManager.getDeviceId();
            if (IMEI == null) {
                Toast.makeText(this, "Can't get your phone's IMEI", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            // Realtime database
            notificationRef = rootRef.child("notifications").child(IMEI).orderByChild("seen").equalTo(false).limitToFirst(1);
            // Firestore
            notificationQuery = notifications
                    .whereEqualTo("imei", IMEI)
                    .whereEqualTo("seen", false)
                    .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
                    .limit(1);
            listenForNotification();
        }
    }

    private void uploadToDatabase() {
        if (rawValue == null) {
            Toast.makeText(this, "QR Code's value is null", Toast.LENGTH_SHORT).show();
        }else {
            Upload upload = new Upload(rawValue, IMEI, null, isTimeIn);
            if (isOnline()) {
                hud.show();
                attendance.add(upload)
                        .addOnCompleteListener(task -> {
                            hud.dismiss();
                            if (task.getException() != null) {
                                Toast.makeText(this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                return;
                            }
                            Alerter.create(MainActivity.this)
                                    .setTitle("Attendance")
                                    .setText("Success Time In.")
                                    .setIcon(R.drawable.done_icon)
                                    .setBackgroundColorRes(R.color.colorAccent)
                                    .setIconColorFilter(0) // Optional - Removes white tint
                                    .enableSwipeToDismiss()
                                    .show();
                        });
            }else {
                Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                String offlineTimestamp = String.valueOf(timestamp.getTime());
                addData(IMEI, offlineTimestamp, rawValue, isTimeIn);
                Alerter.create(MainActivity.this)
                        .setTitle("Attendance")
                        .setText("It looks like you don't have internet connection.")
                        .setIconColorFilter(0) // Optional - Removes white tint
                        .enableSwipeToDismiss()
                        .show();

                Upload upload1 = mDatabaseHelper.getTheLastUpload();
                uploads.add(upload1);
                myAdapter.notifyItemInserted(uploads.size() - 1);
                showTextNoData();
            }
        }
    }

    protected boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

    public boolean addData(String imei, String timestamp, String rawValue, Boolean isTimeIn) {
        boolean isSuccess = mDatabaseHelper.addUpload(imei, timestamp, rawValue, isTimeIn);
        if (!isSuccess) {
            Toast.makeText(this, "Something went wrong.", Toast.LENGTH_SHORT).show();
        }
        return isSuccess;
    }

    private void listenForNotification() {
        // Realtime database
        if (notificationRef != null) {
            notificationRef.addChildEventListener(notificationListener);
        }
        // Firestore
        if (notificationQuery != null) {
            notificationReg = notificationQuery.addSnapshotListener((queryDocumentSnapshots, e) -> {
                if (e != null) {
                    Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    return;
                }
                if (queryDocumentSnapshots == null) {
                    Toast.makeText(this, "Query snapshot is null", Toast.LENGTH_SHORT).show();
                    return;
                }
                for (DocumentChange dc : queryDocumentSnapshots.getDocumentChanges()) {
                    switch (dc.getType()) {
                        case ADDED:
                            // New notification found
                            // TODO: Show the notification
                            dc.getDocument().getReference().update("seen", true);
                            String message = (String) dc.getDocument().getData().get("message");
                            if (message == null) {
                                Toast.makeText(this, "Message is null", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                            break;
                    }
                }
            });
        }
    }

    @SuppressLint("HardwareIds")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == MainActivity.READ_PHONE_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Please turn on the permission request for IMEI in the settings.", Toast.LENGTH_SHORT).show();
                    return;
                }
                IMEI = telephonyManager.getDeviceId();
                if (IMEI == null) {
                    Toast.makeText(this, "Can't get your phone's IMEI", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                notificationRef = rootRef.child("notifications").child(IMEI).orderByChild("seen").equalTo(false).limitToFirst(1);
                notificationQuery = notifications
                        .whereEqualTo("imei", IMEI)
                        .whereEqualTo("seen", false)
                        .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
                        .limit(1);
                listenForNotification();
            }else {
                Toast.makeText(this, "Please turn on the permission request for IMEI in the settings.", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (notificationRef != null && notificationListener != null) {
            notificationRef.removeEventListener(notificationListener);
        }
        if (notificationReg != null) {
            notificationReg.remove();
        }
    }

    private void showTextNoData() {
        if (uploads.size() > 0) {
            textNoData.setVisibility(View.GONE);
        }else {
            textNoData.setVisibility(View.VISIBLE);
        }
    }

}
