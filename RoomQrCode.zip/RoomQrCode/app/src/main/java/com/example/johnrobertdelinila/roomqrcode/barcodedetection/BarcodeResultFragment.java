/*
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.johnrobertdelinila.roomqrcode.barcodedetection;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProviders;

import com.bumptech.glide.Glide;
import com.capstone.e_ticketing.R;
import com.capstone.e_ticketing.camera.WorkflowModel;
import com.capstone.e_ticketing.camera.WorkflowModel.WorkflowState;
import com.capstone.e_ticketing.utils.Transaction;
import com.capstone.e_ticketing.utils.Vendor;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

/** Displays the bottom sheet to present barcode fields contained in the detected barcode. */
public class BarcodeResultFragment extends BottomSheetDialogFragment {

  private static final String TAG = "BarcodeResultFragment";
  private static final String ARG_VENDOR = "arg_vendor";
  private static final String ARG_ERROR = "arg_error";
  private static final String ARG_ID = "arg_id";

  public static void show(FragmentManager fragmentManager, DocumentSnapshot documentSnapshot, String err, int id) {
    BarcodeResultFragment barcodeResultFragment = new BarcodeResultFragment();
    Bundle bundle = new Bundle();

    Vendor vendor = null;
    if (documentSnapshot != null) {
      vendor = documentSnapshot.toObject(Vendor.class);
      if (vendor != null) {
        vendor.setId(documentSnapshot.getId());
      }
    }
    bundle.putSerializable(ARG_VENDOR, (documentSnapshot != null ? vendor : null));

    bundle.putString(ARG_ERROR, err);
    bundle.putInt(ARG_ID, id);
    barcodeResultFragment.setArguments(bundle);
    barcodeResultFragment.show(fragmentManager, TAG);
  }

  public static void dismiss(FragmentManager fragmentManager) {
    BarcodeResultFragment barcodeResultFragment =
        (BarcodeResultFragment) fragmentManager.findFragmentByTag(TAG);
    if (barcodeResultFragment != null) {
      barcodeResultFragment.dismiss();
    }
  }

  @Nullable
  @Override
  public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
    View view = layoutInflater.inflate(R.layout.barcode_bottom_sheet, viewGroup);

    String err = "";
    Vendor vendor;
    int id = 0;

    Bundle arguments = getArguments();
    if (arguments != null && arguments.containsKey(ARG_VENDOR)) {
      vendor = (Vendor) arguments.getSerializable(ARG_VENDOR);
      err = arguments.getString(ARG_ERROR);
      id = arguments.getInt(ARG_ID);
    } else {
      Log.e(TAG, "No barcode field list passed in!");
      vendor = null;
    }

    /*RecyclerView fieldRecyclerView = view.findViewById(R.id.barcode_field_recycler_view);
    fieldRecyclerView.setHasFixedSize(true);
    fieldRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
    fieldRecyclerView.setAdapter(new BarcodeFieldAdapter(barcodeFieldList));*/

    if (vendor != null) {
      if (vendor.getName() != null) {
        ((TextView) view.findViewById(R.id.vendor_name)).setText(vendor.getName());
      }
      if (vendor.getImage() != null && getActivity() != null) {
        Glide.with(getActivity()).load(vendor.getImage()).into(((CircleImageView) view.findViewById(R.id.vendor_image)));
      }
    }else {
      view.findViewById(R.id.vendor_error).setVisibility(View.VISIBLE);
      ((TextView) view.findViewById(R.id.vendor_error)).setText(err);
      view.findViewById(R.id.vendor_container).setVisibility(View.GONE);
    }

    MaterialButton btnTransaction = view.findViewById(R.id.btn_transaction);
    if (id == R.id.fab_payment) {
      btnTransaction.setText(R.string.fab_payment);
    }else if (id == R.id.fab_penalty) {
      btnTransaction.setText(R.string.fab_penalty);
    }else if (id == R.id.fab_pay_penalty) {
      btnTransaction.setText(R.string.fab_pay_penalty);
    }else if (id == R.id.fab_view_vendor) {
      btnTransaction.setText(R.string.fab_view_vendor);
    }

    btnTransaction.setOnClickListener(v -> {
      Transaction transaction = new Transaction();
      transaction.setVendorId(vendor.getId());
      transaction.setTicketerId("Sample uid");
      transaction.setType(btnTransaction.getText().toString());
      transaction.setAmount(Integer.valueOf(String.valueOf(vendor.getSector().get("rent"))));
      transaction.setDate(new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault()).format(new Date()));

      FirebaseFirestore.getInstance().collection("transactions").add(transaction)
              .addOnCompleteListener(task -> {
                if (task.getException() != null) {
                  Log.e(TAG, task.getException().getMessage());
                }
                dismiss();
              });
    });

    return view;
  }

  @Override
  public void onDismiss(@NonNull DialogInterface dialogInterface) {
    if (getActivity() != null) {
      // Back to working state after the bottom sheet is dismissed.
      ViewModelProviders.of(getActivity())
          .get(WorkflowModel.class)
          .setWorkflowState(WorkflowState.DETECTING);
    }
    super.onDismiss(dialogInterface);
  }
}
