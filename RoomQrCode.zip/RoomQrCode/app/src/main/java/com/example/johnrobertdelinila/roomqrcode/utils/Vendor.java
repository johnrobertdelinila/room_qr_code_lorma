package com.example.johnrobertdelinila.roomqrcode.utils;

import java.io.Serializable;
import java.util.Map;

public class Vendor implements Serializable {
    private String image, name, id;
    private Map<String, Object> sector;

    public Vendor() {}

    public Vendor(String image, String name, Map<String, Object> sector) {
        this.image = image;
        this.name = name;
        this.sector = sector;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, Object> getSector() {
        return sector;
    }

    public void setSector(Map<String, Object> sector) {
        this.sector = sector;
    }
}
